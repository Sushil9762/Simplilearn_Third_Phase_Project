package com.simplilearn.Phase3_Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Phase3SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
